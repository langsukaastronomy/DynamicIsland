package com.example.liquidchat

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.eclipse.paho.client.mqttv3.IMqttActionListener
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken
import org.eclipse.paho.client.mqttv3.IMqttToken
import org.eclipse.paho.client.mqttv3.MqttAsyncClient
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended
import org.eclipse.paho.client.mqttv3.MqttConnectOptions
import org.eclipse.paho.client.mqttv3.MqttMessage
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence
import org.json.JSONObject
import org.json.JSONArray
import android.app.AlarmManager
import android.media.AudioManager
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import android.webkit.ValueCallback

const val NS = "lgq7x9"            // harus sama dengan NS di index.html
const val PREFS = "lc"
const val CALL_NOTIF_ID = 2

// Pemutar nada dering + getar (dipakai WebView dan service)
object Ringer {
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private val main = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            ringtone?.let { if (!it.isPlaying) it.play() }
            main.postDelayed(this, 1500)
        }
    }

    fun start(ctx: Context) {
        val app = ctx.applicationContext
        main.post {
            stopNow()
            try {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ringtone = RingtoneManager.getRingtone(app, uri)
                if (Build.VERSION.SDK_INT >= 28) ringtone?.isLooping = true
                ringtone?.play()
                if (Build.VERSION.SDK_INT < 28) main.postDelayed(loop, 1500)
            } catch (_: Exception) { }
            try {
                vibrator = app.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                val pattern = longArrayOf(0, 800, 600)
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } catch (_: Exception) { }
        }
    }

    fun stop() { main.post { stopNow() } }

    private fun stopNow() {
        main.removeCallbacks(loop)
        try { ringtone?.stop() } catch (_: Exception) { }
        ringtone = null
        try { vibrator?.cancel() } catch (_: Exception) { }
    }
}

// Penyimpanan pesan/panggilan tak terjawab yang masuk saat aplikasi di latar belakang
object Store {
    @Synchronized fun add(ctx: Context, o: JSONObject) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val a = try { JSONArray(p.getString("pending_msgs", "[]")) } catch (_: Exception) { JSONArray() }
        a.put(o)
        p.edit().putString("pending_msgs", a.toString()).apply()
    }
    @Synchronized fun drain(ctx: Context): String {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val s = p.getString("pending_msgs", "[]") ?: "[]"
        p.edit().remove("pending_msgs").apply()
        return s
    }
}

class MainActivity : AppCompatActivity() {

    companion object {
        @Volatile var visible = false
    }

    private lateinit var webView: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val pickLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        fileCb?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        fileCb = null
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private fun prefs() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun pendingCall(): String {
        val p = prefs()
        val s = p.getString("pending_call", "") ?: ""
        val ts = p.getLong("pending_ts", 0)
        return if (s.isNotEmpty() && System.currentTimeMillis() - ts < 45000) s else ""
    }

    private fun clearPending() {
        prefs().edit().remove("pending_call").remove("pending_ts").apply()
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(CALL_NOTIF_ID)
    }

    // Jembatan JS -> Android
    inner class AndroidBridge {
        @JavascriptInterface fun startRingtone() { Ringer.start(applicationContext) }

        @JavascriptInterface fun stopRingtone() {
            Ringer.stop()
            runOnUiThread { clearPending() }
        }

        @JavascriptInterface fun setUser(id: String) {
            prefs().edit().putString("user", id).apply()
            runOnUiThread { startKeepAlive(); if (id.isNotEmpty()) askBattery() }
        }

        @JavascriptInterface fun getPendingCall(): String = pendingCall()

        @JavascriptInterface fun drainMsgs(): String = Store.drain(applicationContext)

        @JavascriptInterface fun setSpeaker(on: Boolean) {
            runOnUiThread {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                am.isSpeakerphoneOn = on
            }
        }

        @JavascriptInterface fun resetAudio() {
            runOnUiThread {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.isSpeakerphoneOn = false
                am.mode = AudioManager.MODE_NORMAL
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0C0B0E")
        window.navigationBarColor = Color.parseColor("#0C0B0E")

        requestAllPermissions()
        startKeepAlive()

        webView = WebView(this)
        webView.setBackgroundColor(Color.parseColor("#0C0B0E"))
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }
            // Hilangkan gambar "play" bawaan WebView pada elemen video
            override fun getDefaultVideoPoster(): Bitmap? =
                Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

            // Pemilih foto untuk kirim gambar
            override fun onShowFileChooser(
                w: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { pickLauncher.launch("image/*"); true } catch (_: Exception) { fileCb = null; false }
            }
        }

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onResume() {
        super.onResume()
        visible = true
        webView.onResume()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(3); nm.cancel(4)
        webView.evaluateJavascript("window.pullNative&&window.pullNative()", null)
        val p = pendingCall()
        if (p.isNotEmpty()) {
            webView.evaluateJavascript(
                "window.nativeCall&&window.nativeCall(" + JSONObject.quote(p) + ")", null
            )
        }
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    private fun requestAllPermissions() {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.MODIFY_AUDIO_SETTINGS
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        val need = list.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    private fun askBattery() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName) && !prefs().getBoolean("asked_batt", false)) {
                prefs().edit().putBoolean("asked_batt", true).apply()
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        } catch (_: Exception) { }
    }

    private fun startKeepAlive() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        } catch (_: Exception) { }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else moveTaskToBack(true)
    }

    override fun onDestroy() {
        Ringer.stop()
        super.onDestroy()
    }
}

// Foreground service: menjaga proses hidup + koneksi MQTT native untuk panggilan masuk saat app di latar belakang
class KeepAliveService : Service() {

    private var client: MqttAsyncClient? = null
    private var userId = ""
    private val main = Handler(Looper.getMainLooper())
    private var wake: PowerManager.WakeLock? = null
    private val stopRing = Runnable { clearIncoming() }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("liquid_keepalive", "Koneksi Chat", NotificationManager.IMPORTANCE_LOW)
            )
            val ch = NotificationChannel("liquid_call", "Panggilan Masuk", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
            nm.createNotificationChannel(
                NotificationChannel("liquid_msg", "Pesan", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(this, "liquid_keepalive")
            .setContentTitle("Liquid Chat aktif")
            .setContentText("Menjaga koneksi chat dan panggilan")
            .setSmallIcon(R.drawable.ic_stat_chat)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, notif)
        }
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "liquidchat:mqtt").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        connectIfNeeded()
        return START_STICKY
    }

    private fun connectIfNeeded() {
        val id = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("user", "") ?: ""
        if (id == userId && client != null) return
        disconnect()
        userId = id
        if (id.isEmpty()) return
        Thread {
            try {
                val c = MqttAsyncClient(
                    "wss://broker.emqx.io:8084/mqtt",
                    "${NS}_${id}_svc",
                    MemoryPersistence()
                )
                c.setCallback(object : MqttCallbackExtended {
                    override fun connectComplete(reconnect: Boolean, serverURI: String?) {
                        try { c.subscribe("$NS/u/$id", 1) } catch (_: Exception) { }
                    }
                    override fun connectionLost(cause: Throwable?) { }
                    override fun messageArrived(topic: String?, message: MqttMessage?) {
                        message?.let { handle(String(it.payload)) }
                    }
                    override fun deliveryComplete(token: IMqttDeliveryToken?) { }
                })
                val o = MqttConnectOptions().apply {
                    isAutomaticReconnect = true
                    isCleanSession = false
                    keepAliveInterval = 30
                    connectionTimeout = 15
                }
                client = c
                c.connect(o, null, object : IMqttActionListener {
                    override fun onSuccess(asyncActionToken: IMqttToken?) { }
                    override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                        main.postDelayed({ disconnect(); userId = ""; connectIfNeeded() }, 10000)
                    }
                })
            } catch (_: Exception) {
                client = null
            }
        }.start()
    }

    private fun disconnect() {
        try { client?.disconnectForcibly(0, 0) } catch (_: Exception) { }
        try { client?.close() } catch (_: Exception) { }
        client = null
    }

    private fun handle(s: String) {
        val m = try { JSONObject(s) } catch (_: Exception) { return }
        val from = m.optString("from")
        when (m.optString("type")) {
            "call" -> if (!MainActivity.visible) {
                getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString("pending_call", s).putLong("pending_ts", System.currentTimeMillis()).apply()
                Ringer.start(this)
                showCallNotification(from, m.optBoolean("video"))
                main.removeCallbacks(stopRing)
                main.postDelayed(stopRing, 45000)
            }
            "msg" -> if (!MainActivity.visible) {
                Store.add(this, m)
                notifyText(if (m.has("gn")) m.optString("gn") + " · @$from" else "@$from", if (m.has("img")) "Mengirim foto" else m.optString("text"), 3)
            }
            "end" -> if (!MainActivity.visible) {
                val p = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val pend = try { JSONObject(p.getString("pending_call", "") ?: "") } catch (_: Exception) { null }
                clearIncoming()
                if (pend != null && pend.optString("from") == from) {
                    Store.add(this, JSONObject().put("type", "missed").put("from", from))
                    notifyText("Panggilan tak terjawab", "@$from", 4)
                }
            }
        }
    }

    private fun clearIncoming() {
        Ringer.stop()
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove("pending_call").remove("pending_ts").apply()
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(CALL_NOTIF_ID)
    }

    private fun showCallNotification(from: String, video: Boolean) {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(
            this, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, "liquid_call")
            .setSmallIcon(R.drawable.ic_stat_chat)
            .setContentTitle(if (video) "Panggilan video masuk" else "Panggilan suara masuk")
            .setContentText("@$from")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setOngoing(true)
            .setTimeoutAfter(45000)
            .build()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(CALL_NOTIF_ID, n)
        } catch (_: Exception) { }
    }

    private fun notifyText(title: String, text: String, id: Int) {
        val pi = PendingIntent.getActivity(
            this, id,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, "liquid_msg")
            .setSmallIcon(R.drawable.ic_stat_chat)
            .setContentTitle(title).setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).setContentIntent(pi).build()
        try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n) } catch (_: Exception) { }
    }

    // Aplikasi di-swipe dari recent: jadwalkan service hidup lagi
    override fun onTaskRemoved(rootIntent: Intent?) {
        try {
            val pi = PendingIntent.getForegroundService(
                this, 9, Intent(this, KeepAliveService::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_ONE_SHOT
            )
            (getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                .setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 2000, pi)
        } catch (_: Exception) { }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        disconnect()
        try { wake?.release() } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
