package com.example.liquidvolume

import android.content.Context

object Prefs {
    const val BLURIFY = 0
    const val LIQUID = 1
    private fun sp(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun style(c: Context) = sp(c).getInt("style", LIQUID)
    fun setStyle(c: Context, v: Int) = sp(c).edit().putInt("style", v).apply()
    fun blur(c: Context) = sp(c).getBoolean("blur2", true)
    fun setBlur(c: Context, v: Boolean) = sp(c).edit().putBoolean("blur2", v).apply()
    fun islandOn(c: Context) = sp(c).getBoolean("island", true)
    fun setIslandOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("island", v).apply()
    fun islandIdle(c: Context) = sp(c).getBoolean("idle", true)
    fun setIslandIdle(c: Context, v: Boolean) = sp(c).edit().putBoolean("idle", v).apply()
    fun islandGlass(c: Context) = sp(c).getBoolean("iglass", false)
    fun setIslandGlass(c: Context, v: Boolean) = sp(c).edit().putBoolean("iglass", v).apply()
    fun islandMode(c: Context) = sp(c).getInt("imode", 1) // 0 biasa, 1 iOS
    fun setIslandMode(c: Context, v: Int) = sp(c).edit().putInt("imode", v).apply()
    fun buttons(c: Context) = sp(c).getBoolean("btn", true)
    fun setButtons(c: Context, v: Boolean) = sp(c).edit().putBoolean("btn", v).apply()
}
