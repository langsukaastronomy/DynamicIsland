package com.example.liquidvolume

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min

object ReplyBridge {
    var icon: Drawable? = null
    var title: CharSequence? = null
    var text: CharSequence? = null
    var topY = 0
    var onSend: ((String) -> Unit)? = null
}

/** Layar transparan berisi kartu balas di posisi island; keyboard muncul andal karena ini Activity biasa. */
class ReplyActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        val d = resources.displayMetrics.density
        fun dp(x: Float) = (x * d).toInt()

        val root = FrameLayout(this)
        root.setOnClickListener { finish() }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = 34f * d; setColor(Color.BLACK) }
            setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
            isClickable = true
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply {
            setImageDrawable(ReplyBridge.icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { cornerRadius = 34f * d * 0.28f; setColor(Color.parseColor("#2A2A2E")) }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(34f), dp(34f))
        })
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(10f) }
        }
        fun lbl(t: CharSequence?, sp: Float, c: Int, bold: Boolean) = TextView(this).apply {
            text = t ?: ""; textSize = sp; setTextColor(c); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        col.addView(lbl(ReplyBridge.title, 14f, Color.WHITE, true))
        col.addView(lbl(ReplyBridge.text, 12f, Color.parseColor("#B0B0B8"), false))
        head.addView(col)
        head.addView(lbl("✕", 16f, Color.parseColor("#B0B0B8"), true).apply {
            setPadding(dp(10f), dp(4f), dp(4f), dp(4f))
            setOnClickListener { finish() }
        })
        card.addView(head)

        val et = EditText(this).apply {
            hint = "Balas…"
            setHintTextColor(Color.parseColor("#7C7C86"))
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = GradientDrawable().apply { cornerRadius = 100f * d; setColor(Color.parseColor("#1C1C1E")) }
            setPadding(dp(14f), 0, dp(14f), 0)
            layoutParams = LinearLayout.LayoutParams(0, dp(42f), 1f)
        }
        val send = TextView(this).apply {
            text = "↑"; textSize = 20f; setTextColor(Color.BLACK); gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            layoutParams = LinearLayout.LayoutParams(dp(42f), dp(42f)).apply { marginStart = dp(8f) }
        }
        fun doSend() {
            val t = et.text.toString().trim()
            if (t.isEmpty()) return
            ReplyBridge.onSend?.invoke(t)
            ReplyBridge.onSend = null
            VolumeService.instance?.island?.sentToast()
            finish()
        }
        send.setOnClickListener { doSend() }
        et.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { doSend(); true } else false
        }
        val brow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42f)).apply { topMargin = dp(10f) }
        }
        brow.addView(et)
        brow.addView(send)
        card.addView(brow)

        val sw = resources.displayMetrics.widthPixels
        root.addView(card, FrameLayout.LayoutParams(min(dp(340f), sw - dp(16f)),
            ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ReplyBridge.topY })
        setContentView(root)

        card.alpha = 0f
        card.scaleX = 0.92f
        card.scaleY = 0.92f
        card.pivotY = 0f
        card.post {
            card.pivotX = card.width / 2f
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240)
                .setInterpolator(OvershootInterpolator(1.1f)).start()
        }
        et.requestFocus()
    }

    override fun onStop() { super.onStop(); if (!isFinishing) finish() }

    override fun finish() { super.finish(); overridePendingTransition(0, 0) }
}
