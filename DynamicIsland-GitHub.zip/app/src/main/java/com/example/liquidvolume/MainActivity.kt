package com.example.liquidvolume

import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0E1117")
    private val CARD = Color.parseColor("#161B24")
    private val BLUE = Color.parseColor("#3B82F6")
    private val GREY = Color.parseColor("#9AA4B2")
    private lateinit var cards: List<LinearLayout>
    private lateinit var status: TextView
    private lateinit var primary: Button
    private lateinit var policyBtn: Button
    private lateinit var modeCards: List<LinearLayout>
    private lateinit var listenerBtn: Button
    private val d by lazy { resources.displayMetrics.density }
    private fun dp(x: Int) = (x * d).toInt()

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun bg(stroke: Boolean) = GradientDrawable().apply {
        cornerRadius = 20 * d
        setColor(CARD)
        if (stroke) setStroke(dp(2), BLUE)
    }

    private fun serviceEnabled() =
        Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true

    private fun policyGranted() =
        getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }
        root.addView(col)

        col.addView(tv("Dynamic Island", 26f, Color.WHITE, true))
        col.addView(tv("Dynamic Island + panel volume iOS Liquid Glass", 14f, GREY).apply { setPadding(0, 0, 0, dp(20)) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun card(title: String, sub: String, style: Int): LinearLayout {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(12), dp(16), dp(12), dp(16))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(5), 0, dp(5), 0) }
                setOnClickListener { Prefs.setStyle(this@MainActivity, style); refresh() }
            }
            val prev = GlassPanelView(this, 0.5f, false).apply { this.style = style; snap(0.6f) }
            val holder = FrameLayout(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.parseColor("#1D4ED8"), Color.parseColor("#0EA5A4"))
                ).apply { cornerRadius = 14 * d }
                addView(prev, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            }
            c.addView(holder, LinearLayout.LayoutParams(-1, -2))
            c.addView(tv(title, 15f, Color.WHITE, true).apply { setPadding(0, dp(10), 0, dp(2)) })
            c.addView(tv(sub, 12f, GREY).apply { gravity = Gravity.CENTER })
            return c
        }
        cards = listOf(
            card("Blurify", "Frosted putih bersih", Prefs.BLURIFY),
            card("Liquid glass", "Kaca berasap + lensa", Prefs.LIQUID)
        )
        cards.forEach { row.addView(it) }
        col.addView(row)

        fun switchRow(title: String, sub: String, on: Boolean, enabled: Boolean, cb: (Boolean) -> Unit): LinearLayout {
            val sw = Switch(this).apply {
                isChecked = on; isEnabled = enabled
                setOnCheckedChangeListener { _, v -> cb(v) }
            }
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = bg(false)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
            }
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(tv(title, 15f, Color.WHITE, true))
                addView(tv(sub, 12f, GREY))
            }
            r.addView(t); r.addView(sw)
            return r
        }
        col.addView(switchRow("Blur latar asli", "Android 11+. Di Android 10 otomatis pakai kaca transparan.",
            Prefs.blur(this), Build.VERSION.SDK_INT >= 30) { Prefs.setBlur(this, it) }.also {
            (it.layoutParams as LinearLayout.LayoutParams).topMargin = dp(18)
        })
        col.addView(switchRow("Tombol hening & Jangan ganggu", "Lonceng dan bulan di bawah slider volume.",
            Prefs.buttons(this), true) { Prefs.setButtons(this, it) })

        status = tv("", 13f, GREY).apply { setPadding(0, dp(18), 0, dp(8)) }
        col.addView(status)

        fun btn(primaryStyle: Boolean, click: () -> Unit) = Button(this).apply {
            isAllCaps = false; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 28 * d
                setColor(if (primaryStyle) BLUE else CARD)
            }
            layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) }
            setOnClickListener { click() }
        }
        primary = btn(true) {
            if (!serviceEnabled()) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            else {
                val s = VolumeService.instance
                if (s != null) s.showPanel()
                else Toast.makeText(this, "Layanan sedang dimulai, coba lagi sebentar", Toast.LENGTH_SHORT).show()
            }
        }
        col.addView(primary)

        policyBtn = btn(false) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        col.addView(policyBtn)

        col.addView(btn(false) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }.apply { text = "Atur baterai (agar layanan tidak dimatikan sistem)" })

        col.addView(tv("Pengaturan island", 20f, Color.WHITE, true).apply { setPadding(0, dp(26), 0, dp(4)) })
        col.addView(tv("Pil hitam di sekitar kamera depan: notifikasi, musik, telepon, charging, Wi-Fi.", 12f, GREY))
        col.addView(switchRow("Aktifkan Dynamic Island", "Butuh layanan Aksesibilitas aktif.",
            Prefs.islandOn(this), true) { Prefs.setIslandOn(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(switchRow("Pil selalu tampil di kamera", "Pil hitam menetap, melebar saat ada kejadian.",
            Prefs.islandIdle(this), true) { Prefs.setIslandIdle(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(switchRow("Liquid Glass (eksperimen)", "Island jadi kaca; kilau bergeser saat HP dimiringkan.",
            Prefs.islandGlass(this), true) { Prefs.setIslandGlass(this, it); VolumeService.instance?.island?.refresh() })
        val mrow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        }
        fun modeCard(title: String, sub: String, m: Int): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(5), 0, dp(5), 0) }
            addView(tv(title, 15f, Color.WHITE, true))
            addView(tv(sub, 12f, GREY))
            setOnClickListener { Prefs.setIslandMode(this@MainActivity, m); refresh(); VolumeService.instance?.island?.refresh() }
        }
        modeCards = listOf(
            modeCard("Mode biasa", "Pil hitam, animasi cepat & rapi", 0),
            modeCard("Mode iOS", "Membal seperti iOS + rim cahaya", 1)
        )
        modeCards.forEach { mrow.addView(it) }
        col.addView(mrow)
        listenerBtn = btn(false) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        col.addView(listenerBtn)
        col.addView(btn(false) {
            requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 7)
        }.apply { text = "Izinkan lokasi (untuk menampilkan nama Wi-Fi)" })
        col.addView(btn(true) {
            val s = VolumeService.instance
            if (s == null) Toast.makeText(this, "Aktifkan layanan Aksesibilitas dulu", Toast.LENGTH_SHORT).show()
            else s.island?.demo()
        }.apply { text = "Coba Dynamic Island" })

        setContentView(root)
        refresh()
    }

    override fun onResume() { super.onResume(); if (::cards.isInitialized) refresh() }

    private fun refresh() {
        val cur = Prefs.style(this)
        cards.forEachIndexed { i, c -> c.background = bg(i == cur) }
        val on = serviceEnabled()
        primary.text = if (on) "Coba sekarang" else "Aktifkan layanan (Aksesibilitas)"
        status.text = if (on) "Status: layanan aktif ✓ (tetap aktif walau HP direstart)"
        else "Status: belum aktif. Buka Aksesibilitas → Dynamic Island → nyalakan."
        policyBtn.text = if (policyGranted()) "Akses Jangan Ganggu: sudah diizinkan ✓"
        else "Izinkan akses Jangan Ganggu (untuk mode hening & bulan)"
        modeCards.forEachIndexed { i, c -> c.background = bg(i == Prefs.islandMode(this)) }
        val ln = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        listenerBtn.text = if (ln) "Akses notifikasi: sudah diizinkan ✓"
        else "Izinkan akses notifikasi (untuk notifikasi & musik)"
    }
}
