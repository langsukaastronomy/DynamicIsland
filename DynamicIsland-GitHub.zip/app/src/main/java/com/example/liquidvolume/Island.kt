package com.example.liquidvolume

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Mengelola jendela Dynamic Island: pil idle, kejadian sesaat (kartu) dan aktivitas langsung (musik, navigasi, telepon, timer). */
class Island(private val svc: AccessibilityService) : SensorEventListener {
    companion object { const val K_MUSIC = 0; const val K_TIMER = 1; const val K_NAV = 2; const val K_CALL = 3 }

    private class Live(val key: String, val compact: () -> Pair<View, Float>, val expanded: () -> Triple<View, Float, Float>)
    private class Act(val label: CharSequence, val keep: Boolean, val run: () -> Unit)

    private val d = svc.resources.displayMetrics.density
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val sm = svc.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: IslandView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val lives = HashMap<Int, Live>()
    private var transientActive = false
    private var liveExpanded = false
    private var pendingRemove = false
    private var sensorOn = false
    private var tilt = 0f
    private var lastWifi = 0L
    private var ready = false
    private var lastMusicTitle: String? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var collW = 0f
    private var collH = 0f
    private var cutX = 0f
    private var topY = 0
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val GREEN = Color.parseColor("#30D158")
    private val GREY = Color.parseColor("#B0B0B8")

    private val endTransient = Runnable { transientActive = false; setFocusable(false); settle() }
    private val collapseLive = Runnable { liveExpanded = false; settle() }
    private val dropMusic = Runnable { lives.remove(K_MUSIC); settle() }
    private val power = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { showCharging() }
    }

    init {
        try { svc.registerReceiver(power, IntentFilter(Intent.ACTION_POWER_CONNECTED)) } catch (_: Throwable) {}
        try {
            val cm = svc.getSystemService(ConnectivityManager::class.java)
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { if (ready) showWifi() }
            }
            cm.registerNetworkCallback(req, cb)
            netCb = cb
        } catch (_: Throwable) {}
        handler.postDelayed({ ready = true }, 3000)
        handler.post { settle() }
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        try { svc.unregisterReceiver(power) } catch (_: Throwable) {}
        try { netCb?.let { svc.getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } } catch (_: Throwable) {}
        removeView()
    }

    fun refresh() {
        handler.post {
            transientActive = false
            liveExpanded = false
            removeView()
            settle()
        }
    }

    private fun dp(x: Float) = (x * d).toInt()

    // ---------- sensor kemiringan (Liquid Glass) ----------
    private fun startSensor() {
        if (sensorOn) return
        val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
        sensorOn = true
    }

    private fun stopSensor() {
        if (!sensorOn) return
        sm.unregisterListener(this)
        sensorOn = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        val target = (-e.values[0] / 6f).coerceIn(-1f, 1f)
        tilt += (target - tilt) * 0.12f
        view?.tilt = tilt
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    // ---------- jendela ----------
    private fun readCutout() {
        val wpx = svc.resources.displayMetrics.widthPixels
        val hpx = svc.resources.displayMetrics.heightPixels
        var cw = 0f
        var ch = 0f
        var ctop = -1f
        var cx = 0f
        try {
            @Suppress("DEPRECATION")
            val r = wm.defaultDisplay.cutout?.boundingRects?.firstOrNull { it.top < hpx / 8 && it.width() < wpx / 2 }
            if (r != null) {
                cw = r.width().toFloat(); ch = r.height().toFloat()
                ctop = r.top.toFloat(); cx = r.exactCenterX() - wpx / 2f
            }
        } catch (_: Throwable) {}
        collW = max(if (cw > 0f) cw + dp(18f) else dp(112f).toFloat(), dp(96f).toFloat())
        collH = (if (ch > 0f) ch + dp(4f) else dp(30f).toFloat()).coerceIn(dp(24f).toFloat(), dp(44f).toFloat())
        cutX = cx
        topY = if (ctop >= 0f) (ctop - dp(2f)).toInt().coerceAtLeast(0) else dp(8f)
    }

    private fun ensureView(): IslandView? {
        view?.let { return it }
        if (!Prefs.islandOn(svc)) return null
        readCutout()
        val glass = Prefs.islandGlass(svc)
        val v = IslandView(svc, Prefs.islandMode(svc) == 1, glass)
        v.setColl(collW, collH)
        val p = WindowManager.LayoutParams(
            v.settledW(), v.settledH(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        p.x = cutX.toInt()
        p.y = topY
        v.onWantWindow = { w, h -> applyWindow(w, h) }
        v.onSettled = {
            applyWindow(v.settledW(), v.settledH())
            if (pendingRemove) removeView()
        }
        try { wm.addView(v, p) } catch (_: Exception) { return null }
        view = v
        lp = p
        if (glass) startSensor()
        return v
    }

    private fun applyWindow(w: Int, h: Int) {
        val p = lp ?: return
        val v = view ?: return
        if (p.width == w && p.height == h) return
        p.width = w
        p.height = h
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun setFocusable(on: Boolean) {
        val p = lp ?: return
        val v = view ?: return
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val nf = if (on) p.flags and f.inv() else p.flags or f
        if (nf == p.flags) return
        p.flags = nf
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun removeView() {
        stopSensor()
        val v = view ?: return
        view = null
        lp = null
        pendingRemove = false
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun go(content: View?, twDp: Float, thDp: Float) {
        val v = ensureView() ?: return
        val sw = svc.resources.displayMetrics.widthPixels
        v.go(content, min(dp(twDp), sw - dp(16f)), dp(thDp))
    }

    // ---------- keadaan ----------
    private fun settle() {
        if (!Prefs.islandOn(svc)) { removeView(); return }
        if (transientActive) return
        pendingRemove = false
        val lv = lives.entries.maxByOrNull { it.key }?.value
        if (lv != null) {
            if (liveExpanded) {
                val e = lv.expanded()
                go(e.first, e.second, e.third)
            } else {
                val c = lv.compact()
                c.first.setOnClickListener { expandLive(6000L) }
                go(c.first, c.second, 34f)
            }
        } else if (Prefs.islandIdle(svc)) {
            go(null, 0f, 0f)
        } else {
            val v = view
            if (v != null) { pendingRemove = true; v.go(null, 0, 0) }
        }
    }

    private fun expandLive(ms: Long) {
        liveExpanded = true
        handler.removeCallbacks(collapseLive)
        handler.postDelayed(collapseLive, ms)
        settle()
    }

    private fun present(content: View, tw: Float, th: Float, hold: Long) {
        if (!Prefs.islandOn(svc)) return
        handler.removeCallbacks(endTransient)
        transientActive = true
        go(content, tw, th)
        handler.postDelayed(endTransient, hold)
    }

    private fun endNow() {
        handler.removeCallbacks(endTransient)
        transientActive = false
        setFocusable(false)
        settle()
    }

    // ---------- pembangun tampilan ----------
    private fun label(t: CharSequence?, sp: Float, col: Int, bold: Boolean, lines: Int) = TextView(svc).apply {
        text = t ?: ""; textSize = sp; setTextColor(col); maxLines = lines
        ellipsize = TextUtils.TruncateAt.END
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun roundIcon(dr: Drawable?, sizeDp: Float) = ImageView(svc).apply {
        setImageDrawable(dr)
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = GradientDrawable().apply { cornerRadius = sizeDp * d * 0.28f; setColor(Color.parseColor("#2A2A2E")) }
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun pill(txt: CharSequence, col: Int = Color.parseColor("#2C2C31"), onClick: () -> Unit) = TextView(svc).apply {
        text = txt; setTextColor(Color.WHITE); textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setPadding(dp(10f), 0, dp(10f), 0)
        background = GradientDrawable().apply { cornerRadius = 100f * d; setColor(col) }
        layoutParams = LinearLayout.LayoutParams(0, dp(34f), 1f).apply { setMargins(dp(4f), 0, dp(4f), 0) }
        setOnClickListener { onClick() }
    }

    private fun sideViews(left: View, right: View): View {
        val f = FrameLayout(svc)
        f.addView(left, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(16f) })
        f.addView(right, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(16f) })
        return f
    }

    private fun sideRow(l: String, r: String, lc: Int, rc: Int) =
        sideViews(label(l, 14f, lc, true, 1), label(r, 14f, rc, true, 1))

    private fun card(icon: Drawable?, title: CharSequence?, text: CharSequence?, acts: List<Act>,
                     tap: (() -> Unit)?, extra: View? = null): Pair<View, Float> {
        val root = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(12f))
        }
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(roundIcon(icon, 44f))
        val col = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12f) }
        }
        col.addView(label(title, 15f, Color.WHITE, true, 1))
        if (extra != null) col.addView(extra) else col.addView(label(text, 13f, GREY, false, 2))
        row.addView(col)
        root.addView(row)
        if (acts.isNotEmpty()) {
            val ar = LinearLayout(svc).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34f)).apply { topMargin = dp(10f) }
            }
            acts.forEach { a -> ar.addView(pill(a.label) { a.run(); if (!a.keep) endNow() }) }
            root.addView(ar)
        }
        if (tap != null) root.setOnClickListener { tap() }
        return Pair(root, if (acts.isEmpty()) 88f else 134f)
    }

    private fun appIcon(sbn: StatusBarNotification): Drawable? {
        try { sbn.notification.getLargeIcon()?.let { return it.loadDrawable(svc) } } catch (_: Throwable) {}
        try { return svc.packageManager.getApplicationIcon(sbn.packageName) } catch (_: Throwable) {}
        try { sbn.notification.smallIcon?.let { return it.loadDrawable(svc) } } catch (_: Throwable) {}
        return null
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val ss = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, ss) else String.format(Locale.US, "%d:%02d", m, ss)
    }

    private fun tapOf(sbn: StatusBarNotification): (() -> Unit)? {
        val pi = sbn.notification.contentIntent ?: return null
        return { try { pi.send() } catch (_: Exception) {}; endNow(); liveExpanded = false; settle() }
    }

    private fun actsOf(sbn: StatusBarNotification, max: Int, replyIcon: Drawable?): List<Act> {
        val out = ArrayList<Act>()
        val ex = sbn.notification.extras
        (sbn.notification.actions ?: emptyArray()).forEach { a ->
            val pi = a.actionIntent
            val t = a.title
            if (pi == null || t.isNullOrBlank() || out.size >= max) return@forEach
            val ri = a.remoteInputs
            if (ri != null && ri.isNotEmpty()) {
                out.add(Act(t, true) {
                    openReply(replyIcon, ex.getCharSequence(Notification.EXTRA_TITLE),
                        ex.getCharSequence(Notification.EXTRA_TEXT)) { msg ->
                        try {
                            val i = Intent()
                            val b = Bundle()
                            b.putCharSequence(ri[0].resultKey, msg)
                            RemoteInput.addResultsToIntent(ri, i, b)
                            pi.send(svc, 0, i)
                        } catch (_: Throwable) {}
                    }
                })
            } else {
                out.add(Act(t, false) { try { pi.send() } catch (_: Exception) {} })
            }
        }
        return out
    }

    // ---------- kartu notifikasi + balas ----------
    fun showNotification(sbn: StatusBarNotification, isCall: Boolean) {
        handler.post {
            val ex = sbn.notification.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)
            val text = ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT)
            if (title == null && text == null) return@post
            val icon = appIcon(sbn)
            val built = card(icon, title, text, actsOf(sbn, 2, icon), tapOf(sbn))
            present(built.first, 340f, built.second, if (isCall) 25000L else 5000L)
        }
    }

    private fun openReply(icon: Drawable?, title: CharSequence?, text: CharSequence?, onSend: (String) -> Unit) {
        endNow()
        ReplyBridge.icon = icon
        ReplyBridge.title = title
        ReplyBridge.text = text
        ReplyBridge.topY = topY
        ReplyBridge.onSend = onSend
        try {
            svc.startActivity(Intent(svc, ReplyActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
        } catch (_: Throwable) {
            handler.post { present(sideRow("Gagal buka balas", "", GREY, GREY), 260f, 36f, 2000L) }
        }
    }

    fun sentToast() {
        handler.post { present(sideRow("✓ Terkirim", "", GREEN, GREEN), 220f, 36f, 1300L) }
    }

    // ---------- charging, wifi, demo ----------
    fun showCharging() {
        handler.post {
            val i = svc.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val scale = (i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
            present(sideRow("⚡ Charging", "${lvl * 100 / scale}%", GREEN, GREEN), 250f, 36f, 3000L)
        }
    }

    private fun ssid(): String? = try {
        if (svc.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) null
        else {
            @Suppress("DEPRECATION")
            val s = (svc.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo?.ssid?.trim('"')
            if (s == null || s == "<unknown ssid>") null else s
        }
    } catch (_: Throwable) { null }

    fun showWifi() {
        handler.post {
            val now = System.currentTimeMillis()
            if (now - lastWifi < 10000) return@post
            lastWifi = now
            present(sideRow(ssid() ?: "Wi-Fi", "Connected", Color.WHITE, Color.parseColor("#0A84FF")), 270f, 36f, 2500L)
        }
    }

    fun demo() {
        handler.post {
            val icon = try { svc.packageManager.getApplicationIcon(svc.packageName) } catch (_: Throwable) { null }
            val acts = listOf(
                Act("Balas", true) { openReply(icon, "Anna", "Hei! Lihat island-nya sekarang 👋") { } },
                Act("Tandai dibaca", false) { }
            )
            val built = card(icon, "Anna", "Hei! Lihat island-nya sekarang 👋", acts, null)
            present(built.first, 340f, built.second, 6000L)
        }
    }

    // ---------- aktivitas langsung ----------
    fun removeByKey(key: String) {
        handler.post {
            val hit = lives.entries.firstOrNull { it.value.key == key }
            if (hit != null) { lives.remove(hit.key); settle() }
        }
    }

    // Musik
    private fun pos(c: MediaController): Long {
        val s = c.playbackState ?: return 0L
        var p = s.position
        if (s.state == PlaybackState.STATE_PLAYING) {
            p += ((SystemClock.elapsedRealtime() - s.lastPositionUpdateTime) * s.playbackSpeed).toLong()
        }
        return p.coerceAtLeast(0L)
    }

    private fun dur(c: MediaController) = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

    fun musicLive(c: MediaController, playing: Boolean) {
        handler.post {
            val title = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return@post
            handler.removeCallbacks(dropMusic)
            lives[K_MUSIC] = Live("music", { musicCompact(c, playing) }, { musicExpanded(c, playing) })
            if (!playing) handler.postDelayed(dropMusic, 20000)
            if (playing && title != lastMusicTitle) { lastMusicTitle = title; expandLive(6000L) } else settle()
        }
    }

    fun musicGone() {
        handler.post {
            handler.removeCallbacks(dropMusic)
            lastMusicTitle = null
            if (lives.remove(K_MUSIC) != null) settle()
        }
    }

    private fun artOf(c: MediaController) = c.metadata?.let {
        it.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: it.getBitmap(MediaMetadata.METADATA_KEY_ART)
        ?: it.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
    }

    private fun musicCompact(c: MediaController, playing: Boolean): Pair<View, Float> {
        val art = roundIcon(null, 24f)
        artOf(c)?.let { art.setImageBitmap(it) }
        val bars = BarsView(svc, Color.parseColor("#FF375F"), 4, 22, 16).apply { active = playing }
        return Pair(sideViews(art, bars), 240f)
    }

    private fun musicExpanded(c: MediaController, playing: Boolean): Triple<View, Float, Float> {
        val m = c.metadata
        val root = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(6f))
        }
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val art = roundIcon(null, 52f)
        artOf(c)?.let { art.setImageBitmap(it) }
        row.addView(art)
        val col = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12f) }
        }
        col.addView(label(m?.getString(MediaMetadata.METADATA_KEY_TITLE), 15f, Color.WHITE, true, 1))
        col.addView(label(m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST), 13f, GREY, false, 1))
        row.addView(col)
        row.addView(BarsView(svc, Color.parseColor("#FF375F"), 4, 22, 16).apply { active = playing })
        root.addView(row)

        val prog = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(22f)).apply { topMargin = dp(8f) }
        }
        val t1 = TickText(svc) { fmt(pos(c)) }.apply { textSize = 11f; setTextColor(GREY) }
        val bar = BarProgress(svc) { val dd = dur(c); if (dd > 0) pos(c).toFloat() / dd else 0f }
            .apply { layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(dp(8f), 0, dp(8f), 0) } }
        val t2 = TickText(svc) { val dd = dur(c); if (dd > 0) "-" + fmt(dd - pos(c)) else "" }.apply { textSize = 11f; setTextColor(GREY) }
        prog.addView(t1); prog.addView(bar); prog.addView(t2)
        root.addView(prog)

        fun ctl(glyph: String, act: () -> Unit) = TextView(svc).apply {
            text = glyph; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            setOnClickListener {
                try { act() } catch (_: Throwable) {}
                expandLive(6000L)
            }
        }
        val ctrls = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46f)).apply { topMargin = dp(4f) }
        }
        ctrls.addView(ctl("⏮") { c.transportControls.skipToPrevious() })
        ctrls.addView(ctl(if (playing) "⏸" else "▶") { if (playing) c.transportControls.pause() else c.transportControls.play() })
        ctrls.addView(ctl("⏭") { c.transportControls.skipToNext() })
        root.addView(ctrls)
        return Triple(root, 340f, 158f)
    }

    // Navigasi (notifikasi Google Maps dkk.)
    fun navLive(sbn: StatusBarNotification) {
        handler.post {
            val n = sbn.notification
            val ex = n.extras
            val dist = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val street = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            val eta = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""
            val arrow = try { n.getLargeIcon()?.loadDrawable(svc) } catch (_: Throwable) { null }
            val tap = tapOf(sbn)
            lives[K_NAV] = Live(sbn.key, {
                val left: View = if (arrow != null) ImageView(svc).apply {
                    setImageDrawable(arrow); layoutParams = FrameLayout.LayoutParams(dp(24f), dp(24f))
                } else label("➤", 16f, GREEN, true, 1)
                Pair(sideViews(left, label(dist, 14f, GREEN, true, 1)), 250f)
            }, {
                val root = LinearLayout(svc).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16f), dp(14f), dp(16f), dp(12f))
                }
                val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val ic = roundIcon(arrow, 52f)
                ic.setBackgroundColor(Color.parseColor("#12301F"))
                row.addView(ic)
                val col = LinearLayout(svc).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12f) }
                }
                col.addView(label(dist, 22f, Color.WHITE, true, 1))
                col.addView(label(street, 13f, GREY, false, 1))
                row.addView(col)
                root.addView(row)
                val er = LinearLayout(svc).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34f)).apply { topMargin = dp(10f) }
                }
                val etaV = label(eta, 13f, GREEN, true, 1)
                etaV.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                er.addView(etaV)
                val open = pill("Buka", Color.parseColor("#1F8F45")) { tap?.invoke() }
                open.layoutParams = LinearLayout.LayoutParams(dp(84f), dp(34f))
                er.addView(open)
                root.addView(er)
                Triple(root, 340f, 128f)
            })
            settle()
        }
    }

    // Telepon berlangsung
    fun callLive(sbn: StatusBarNotification) {
        handler.post {
            val n = sbn.notification
            val base = n.`when`
            val name = n.extras.getCharSequence(Notification.EXTRA_TITLE)
            val icon = appIcon(sbn)
            lives[K_CALL] = Live(sbn.key, {
                val left = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                left.addView(label("📞 ", 13f, GREEN, true, 1))
                left.addView(TickText(svc) { fmt(System.currentTimeMillis() - base) }.apply {
                    textSize = 14f; setTextColor(GREEN); setTypeface(typeface, Typeface.BOLD)
                })
                Pair(sideViews(left, BarsView(svc, GREEN, 5, 28, 16)), 260f)
            }, {
                val timer = TickText(svc) { fmt(System.currentTimeMillis() - base) }.apply { textSize = 14f; setTextColor(GREEN) }
                val b = card(icon, name, null, actsOf(sbn, 2, icon), tapOf(sbn), timer)
                Triple(b.first, 340f, b.second)
            })
            settle()
        }
    }

    // Timer / stopwatch (notifikasi chronometer)
    fun timerLive(sbn: StatusBarNotification) {
        handler.post {
            val n = sbn.notification
            val base = n.`when`
            val down = n.extras.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN)
            val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)
            val icon = appIcon(sbn)
            val amber = Color.parseColor("#FF9F0A")
            val value: () -> String = {
                val now = System.currentTimeMillis()
                fmt(if (down) base - now else now - base)
            }
            lives[K_TIMER] = Live(sbn.key, {
                val t = TickText(svc, value).apply { textSize = 14f; setTextColor(amber); setTypeface(typeface, Typeface.BOLD) }
                Pair(sideViews(label("⏱", 16f, amber, true, 1), t), 230f)
            }, {
                val t = TickText(svc, value).apply { textSize = 20f; setTextColor(amber); setTypeface(typeface, Typeface.BOLD) }
                val b = card(icon, title, null, actsOf(sbn, 2, icon), tapOf(sbn), t)
                Triple(b.first, 340f, b.second)
            })
            settle()
        }
    }
}
