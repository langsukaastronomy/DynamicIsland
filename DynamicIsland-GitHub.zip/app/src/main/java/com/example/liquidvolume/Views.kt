package com.example.liquidvolume

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Batang equalizer / gelombang suara yang bergerak halus. */
class BarsView(ctx: Context, col: Int, private val bars: Int, wDp: Int, hDp: Int) : View(ctx) {
    var active = true
    private val d = resources.displayMetrics.density
    private val w = (wDp * d).toInt()
    private val h = (hDp * d).toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onMeasure(a: Int, b: Int) = setMeasuredDimension(w, h)
    override fun onDraw(c: Canvas) {
        val bw = w / (bars * 2f - 1f)
        for (i in 0 until bars) {
            val f = if (active) 0.28f + 0.72f * abs(sin(2.0 * PI * (t + i * 0.21)).toFloat()) else 0.28f
            val bh = h * f
            val x = i * bw * 2f
            c.drawRoundRect(x, (h - bh) / 2f, x + bw, (h + bh) / 2f, bw / 2f, bw / 2f, p)
        }
    }
}

/** Teks yang memperbarui dirinya tiap detik (timer, durasi telepon, posisi lagu). */
class TickText(ctx: Context, private val supplier: () -> String) : TextView(ctx) {
    private val r = object : Runnable {
        override fun run() { text = supplier(); postDelayed(this, 1000) }
    }
    init { fontFeatureSettings = "tnum" }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); r.run() }
    override fun onDetachedFromWindow() { removeCallbacks(r); super.onDetachedFromWindow() }
}

/** Progress bar lagu. */
class BarProgress(ctx: Context, private val supplier: () -> Float) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val r = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 250) }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); r.run() }
    override fun onDetachedFromWindow() { removeCallbacks(r); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val h = 4 * d
        val top = (height - h) / 2f
        p.color = Color.argb(70, 255, 255, 255)
        rr.set(0f, top, width.toFloat(), top + h)
        c.drawRoundRect(rr, h / 2f, h / 2f, p)
        p.color = Color.WHITE
        rr.right = width * supplier().coerceIn(0f, 1f)
        c.drawRoundRect(rr, h / 2f, h / 2f, p)
    }
}
